package practice;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class MainClass {

	public static void main(String[] args) {

		//HashSet<Employee> employee=new HashSet<>();
		
		TreeSet<Employee> employee=new TreeSet<>();
		employee.add(new Employee(191,"tom","jerry",25,25000));
		employee.add(new Employee(121,"jack","jerry",52,5233));
		employee.add(new Employee(113,"tom","jack",15,25000));
		employee.add(new Employee(151,"jerry","jack",65,55422));
		
		//employee.add(new Employee(151,"jerry","jack",65,55422));
		
		Iterator<Employee> iterator=employee.iterator();//headpointer
		
		while(iterator.hasNext())
		{
			Employee emp=iterator.next();
			System.out.println(emp+" ");
		}
		System.out.println();

	}

}
