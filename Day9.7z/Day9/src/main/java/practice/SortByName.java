package practice;

import java.util.Comparator;

public class SortByName implements Comparator<Employee>{

	

		public int compare(Employee emp1,Employee emp2) {
			// TODO Auto-generated method stub
			if(emp1.getfName().compareTo(emp2.getfName())>0)
				return 1;
			else if(emp1.getfName().compareTo(emp2.getfName())<0)
				return -1;
			else
				return 0;
				
			
		
	}

}
