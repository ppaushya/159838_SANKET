package practice;

import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashTableDemo {

	public static void main(String[] args) {
		Map<Integer,String> map=new Hashtable<>();
	map.put(1, "one");
	map.put(4,"two");
	map.put(3,"three");
	map.put(1,"four");//will override value of key=1
	map.put(2,"one");//value can be duplicate
	//map.put(null,"five");//null not allowed
//	map.put(null,"seven");
	map.put(111,"rdxg");
	map.put(65786,"hjgh");
	map.put(76,"nbvng");
	
	System.out.println(map);
	
	/*Set<Integer> set=map.keySet();
	Iterator<Integer> iterator=set.iterator();
	while(iterator.hasNext())
	{
		int key=iterator.next();
		System.out.println(key+"-->"+map.get(key));
}*/
	
	
	/*Collection<String> values=map.values();
	for(String str:values)
		System.out.println(str);*/
	
	
	//enumeration
	Enumeration<String> enumeration=((Hashtable<Integer, String>) map).elements();
	while(enumeration.hasMoreElements())
		System.out.println(enumeration.nextElement());

	}

}
