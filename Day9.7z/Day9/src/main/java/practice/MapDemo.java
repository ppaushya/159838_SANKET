package practice;
//hashMap
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer,String> map=new HashMap<>();
		map.put(1, "one");
		map.put(4,"two");
		map.put(3,"three");
		map.put(1,"four");//will override value of key=1
		map.put(2,"one");//value can be duplicate
//		map.put(null,"five");
//		map.put(null,"seven");//override value of key =null
		map.put(111,"rdxg");
		map.put(65786,"hjgh");
		map.put(76,"nbvng");
		
		System.out.println(map);
		
		/*Set<Integer> set=map.keySet();
		Iterator<Integer> iterator=set.iterator();
		while(iterator.hasNext())
		{
			int key=iterator.next();
			System.out.println(key+"-->"+map.get(key));
	}*/
		
		
		Collection<String> values=map.values();
		for(String str:values)
			System.out.println(str);
		
		
	}

}
