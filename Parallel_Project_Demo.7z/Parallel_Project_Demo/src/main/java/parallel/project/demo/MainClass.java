package parallel.project.demo;
import java.util.*;
public class MainClass {
    static boolean isPresent(int customerId,Customer[] c,int n)
    {
        int found=0;
        for(int i=0;i<n;i++)
            {
             if(c[i].getCustomerId()==customerId)
             {
                found=1;
                return true;
             }
            }
            return false;
    }
    static int getIndex(int customerId,Customer[] c,int n)
    {
        for(int i=0;i<n;i++)
            {
             if(c[i].getCustomerId()==customerId)
             {
                return i;
             }
            }
        return -1;
    }
	public static void main(String[] args)
	{
           int j;
        int customerId;
	String name;
        String mobileNo;
	String emailId;
        int accountCount;
        accountCount = 0;
        
        String stName;
	String city;
	String state;
        
        long accountNo;
	int type;
        String accountType="";
	double openingBalance;
        double currentBalance;
        
	Scanner sc=new Scanner(System.in);
        System.out.println("------------Welcome to Banking Demo------------");
	System.out.println("Enter the number of customer:");
	int n=sc.nextInt();
        
	System.out.println("Enter details of customers.");
	Customer[] c=new Customer[n];
	for(int i=0;i<n;i++)
        {
            System.out.println("Enter the Customer ID "+(i+1));
            customerId=sc.nextInt();
            //sc.next();
            System.out.println("Enter the name of Customer "+(i+1));
            name=sc.next();
             System.out.println("Enter the mobile No of Customer "+(i+1));
            mobileNo=sc.next();
             System.out.println("Enter the emailid of Customer "+(i+1));
            emailId=sc.next();
            System.out.println("Enter the address of Customer "+(i+1));
            System.out.println("Enter Street no");
            stName=sc.next();
            System.out.println("Enter city name");
            city=sc.next();
            System.out.println("Enter State");
	    state=sc.next();
            c[i]=new Customer(customerId,name,stName,city,state,mobileNo,emailId);
        }
        char choice;
        choice = 'Y';
        int ch;
        do
        {
            System.out.println("Enter one of the choice:");
            System.out.println("\t1. Display CustomerDetails\n\t2. Create Account\n\t3. Do Trancaction\n\t4. Show Summary\n\t5. Display Customer's Account Details\n");
            ch=sc.nextInt();
            switch(ch)
            {
                case 1://display customer details
                    System.out.println("Enter Customer ID:");
                    customerId=sc.nextInt();
                    int found=0;
                    for(int i=0;i<n;i++)
                    {
                        if(c[i].getCustomerId()==customerId)
                        {
                            System.out.println("\tDetails of customer with id= "+c[i].getCustomerId());
                            System.out.println("Name of Customer :"+c[i].getName());
                            System.out.println("Mobile No of Customer :"+c[i].getMobile());
                            System.out.println("Emailid of Customer :"+c[i].getEmail());
                            System.out.println("Address of Customer :"+c[i].getAddress() );
                            found=1;
                        }
                    }
                    if(found==0)
                    {
                        System.out.println("Customer do not exit.");
                    }
                    break;
                case 2://creation of account for given customer
                    System.out.println("Enter Customer ID:");
                    customerId=sc.nextInt();
                    if(!isPresent(customerId, c, n))
                    {System.out.println("Customer do not exit.");break;}
                    int index=getIndex(customerId, c, n);
                    accountCount++;
                    System.out.println("Account count"+accountCount);
                    c[index].setAccountCount(accountCount);
                    System.out.println("Enter Account No for Customer ID " + c[index].getCustomerId());
                    accountNo=sc.nextLong();
                    System.out.println("Enter Account Type for Customer ID " + c[index].getCustomerId());
                    System.out.println("Enter 1. Saving\t2. Current\t3. FD\t4. RD");
                    type=sc.nextInt();
                    switch(type)
                            {
                                case 1:
                                    accountType="Saving";
                                break;
                                case 2:
                                    accountType="Current";
                                break;
                                case 3:
                                    accountType="FD";
                                break;
                                case 4:
                                    accountType="RD";
                                break;
                                default:
                                    System.out.println("Not a valid input");
                            }
                    System.out.println("Enter Opening Balance for Customer ID " + c[index].getCustomerId());
                    openingBalance=sc.nextDouble();
                    c[index].setAccount(accountCount,accountNo,accountType,openingBalance);
                    break;
                case 3://do transaction
                    System.out.println("Enter Customer ID:");
                    customerId=sc.nextInt();
                    if(!isPresent(customerId, c, n))
                    {
                        System.out.println("Customer do not exit.");
                        break;
                    }
                    index=getIndex(customerId, c, n);
                    System.out.println("Enter account number for transaction:");
                    accountNo=sc.nextLong();
                    j=c[index].getAccountCount();
                    int flag=0;
                    for(int i=1;i<=j;i++)
                    {
                        if(accountNo==c[index].getAccountNo(i))
                        {
                            flag=1;
                            System.out.println("Enter 1. Debit\t2. Credit");
                            int db_cr;
                            double amount;
                            db_cr=sc.nextInt();
                            switch(db_cr)
                            {
                                case 1:
                                    System.out.println("Enter amount to be debited");
                                    amount=sc.nextDouble();
                                    currentBalance=c[index].getCurrentBalance(i);
                                    if(amount<currentBalance)
                                    {
                                        
                                        c[index].setCurrentBalance(currentBalance-amount,i);
                                        System.out.println("Amount credited successfully");
                                        System.out.println("Current Balance "+c[index].getCurrentBalance(i));
                                    }
                                    else
                                    {
                                        System.out.println("The amount entered is not valid");
                                    }
                                    
                                    break;
                                case 2:
                                    System.out.println("Enter amount to be credited");
                                    amount=sc.nextDouble();
                                    currentBalance=c[index].getCurrentBalance(i);
                                    c[index].setCurrentBalance(currentBalance+amount,i);
                                    System.out.println("Amount credited successfully");
                                    System.out.println("Current Balance "+c[index].getCurrentBalance(i));
                                    break;
                                default:
                                    System.out.println("Not a valid input");
                            }
                            break;
                        }
                    }
                    if(flag==0)
                    {
                        System.out.println("This account number doesnot exit for customer with Id= "+c[index].getCustomerId());
                    }
                    break;
                case 4:
                    System.out.println("Not implemented");
                    break;
                case 5:
                    
                    System.out.println("Enter Customer ID:");
                    customerId=sc.nextInt();
                    if(!isPresent(customerId, c, n))
                    {
                        System.out.println("Customer do not exit.");
                        break;
                    }
                    index=getIndex(customerId, c, n);
                    System.out.println("Name of Customer :"+c[index].getName());
                    System.out.println("Mobile No of Customer :"+c[index].getMobile());
                    System.out.println("Emailid of Customer :"+c[index].getEmail());
                    System.out.println("Address of Customer :"+c[index].getAddress() );
                    j=c[index].getAccountCount();
                    for(int i=1;i<=j;i++)
                    {
                        System.out.println("Account No "+i+"details:");
                        System.out.println("Account No :"+c[index].getAccountNo(i));
                        System.out.println("Account Type :"+c[index].getAccountType(i));
//                      System.out.println("Opening Date "+c[index].getOpeningDate(i));
                        System.out.println("Opening Balance :"+c[index].getOpeningBalance(i));
                        System.out.println("Current Balance :"+c[index].getCurrentBalance(i));
                        System.out.println();
                    }
                    break;
                    default:
                        System.out.println("Not a valid input");
                } 
            System.out.println("To continue, enter Y/y :");
            choice=sc.next().charAt(0);
        }while(choice=='Y'||choice=='y');
}
}

