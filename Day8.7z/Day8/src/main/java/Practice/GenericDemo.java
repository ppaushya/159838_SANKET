package Practice;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
public class GenericDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//List<Integer> lst=new ArrayList<Integer>();not necessary to put Integer on both dide of<>
		List<Integer> lst=new ArrayList<>();
		
		
		lst.add(3);
//		lst.add("Tom");
//		lst.add(45.66);
		lst.add(123564789);
//		lst.add(new Object());
		lst.add(123564789);//duplicates allowed
		lst.add(null);//null allowed
	}

}
