package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;

public class AccountDaoImpl implements IAccountDao	{
	
	
	@Override
	public Set<Account> getAccountsOfCustomer(Customer customer)
	{
		Set<Account> accounts=new HashSet<>();
		String str="select * from account where customerId="+customer.getCustomerId()+";";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Account account=new Account();
				AccountType accType=AccountType.SAVINGS;
				
					account.setAccountNo(resultSet.getLong(2));
					account.setAccountType(accType.valueOf(resultSet.getString(3).toUpperCase()));
					account.setOpeningDate(resultSet.getDate(4).toLocalDate());
					account.setOpeningBalance(resultSet.getDouble(5));
					account.setDescription(resultSet.getString(6));
					accounts.add(account);
			
			}
		}	catch (SQLException e) {
			
			e.printStackTrace();
		}
		return accounts;
	}
	
	@Override
	public void createAccount(Account account, int customerId)
	{
		String sql="insert into account values(?,?,?,?,?,?);";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, customerId);
			statement.setLong(2, account.getAccountNo());
			statement.setString(3, account.getAccountType().toString());
			statement.setDate(4, java.sql.Date.valueOf(account.getOpeningDate()));
			statement.setDouble(5, account.getOpeningBalance());
			statement.setString(6, account.getDescription());
			
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Accounts table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
