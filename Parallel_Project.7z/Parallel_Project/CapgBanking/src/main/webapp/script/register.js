function validate()
{
	var flag=false;
  var fname=f2.firstName.value;
 var lname=f2.lastName.value;
 var valname="/^[a-zA-Z]+$/";
        if(!fname.match(valname)){
        	
		    document.getElementById('fnameErrMsg').innerHTML="*FirstName should contain Alphabets.";
		    flag=false;
        }
        else  if(!lname.match(valname)){
        	
    		document.getElementById('lnameErrMsg').innerHTML="*LastName should contain Alphabets.";
    		flag=false;
            }
        else
        	{
        	document.getElementById('fnameErrMsg').innerHTML="";
        	document.getElementById('lnameErrMsg').innerHTML="";
        	flag=true;
        	}
		


}