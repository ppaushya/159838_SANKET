package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Account;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;


@WebServlet("/AccountServlet")
public class Accountservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 IAccountService accountService=new AccountServiceImpl();
	       Account account=new Account();
	     account.setAccountType(AccountType.valueOf(request.getParameter("accountType")));
	     account.setOpeningBalance(Double.parseDouble(request.getParameter("balance")));
	     account.setDescription(request.getParameter("description"));
	     account.setOpeningDate(LocalDate.now());
	 	
			HttpSession session=request.getSession();
			int custId=Integer.parseInt(session.getAttribute("custId").toString());
			Customer customer=new Customer();
			customer.setCustomerId(custId);
			account.setCustomer(customer);
			System.out.println(account);
	     accountService.createAccount(account);
	     response.sendRedirect("./view/createAccount.html");
		
	}

}
