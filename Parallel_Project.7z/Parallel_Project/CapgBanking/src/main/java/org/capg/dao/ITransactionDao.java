package org.capg.dao;

import java.time.LocalDate;
import java.util.List;

import java.util.Map;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public interface ITransactionDao {

	//public List<Transaction> getAllTransactions(Customer customer,LocalDate fromdate,LocalDate todate);
	public List<Transaction> getAllTransactions(Customer customer);
	public void createTransaction(Transaction transaction);
	
}
