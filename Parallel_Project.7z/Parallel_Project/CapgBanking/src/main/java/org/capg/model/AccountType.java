package org.capg.model;

public enum AccountType {

	SAVINGS,CURRENT,RD,FD;
	
}
