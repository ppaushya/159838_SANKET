package org.capg.service;

import org.capg.model.Customer;
import org.capg.model.LoginBean;

public interface ILoginService {
	
	public Customer isValidLogin(LoginBean loginBean);

}
