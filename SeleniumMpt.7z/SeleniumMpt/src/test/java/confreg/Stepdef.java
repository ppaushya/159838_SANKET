package confreg;


import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	private WebDriver webDriver;
	private WebElement webElement;
	

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sankekum\\Selenium\\chromedriver\\chromedriver.exe");
	 webDriver = new ChromeDriver();
	}
	
	@Given("^Conference Registration page$")
	public void conference_Registration_page() throws Throwable {
		webDriver.get("file:///C:/Users/sankekum/Pictures/Conferencebooking/ConferenceRegistartion.html");
	}

	@When("^Verify title of the page$")
	public void verify_title_of_the_page() throws Throwable {
		/**String title=webDriver.getTitle();
		assertEquals("Conference Registration", title);
		 if(title.equals("Conference Registration"))
		 {
			 
		 }
		 else {
			 webDriver.quit();
		 }
		**/
		webDriver.findElement(By.xpath("/html/body/h2"));
	}

	@When("^Verify heading of the page$")
	public void verify_heading_of_the_page() throws Throwable {
		webDriver.findElement(By.xpath("/html/body/h4"));
		
	}

	@When("^Enter User details$")
	public void enter_User_details() throws Throwable {
		webDriver.findElement(By.name("txtFN")).sendKeys("Hari");
		webDriver.findElement(By.name("txtLN")).sendKeys("Om");
		webDriver.findElement(By.name("Email")).sendKeys("hari@gmail.com");
		webDriver.findElement(By.name("Phone")).sendKeys("8789321659");
		Select dropdown = new Select(webDriver.findElement(By.name("size")));
		dropdown.selectByVisibleText("5");
		webDriver.findElement(By.name("Address")).sendKeys("SMR");
		webDriver.findElement(By.name("Address2")).sendKeys("Metro railway");
		Select dropdown1 = new Select(webDriver.findElement(By.name("city")));
		dropdown1.selectByVisibleText("Hyderabad");

		Select dropdown2 = new Select(webDriver.findElement(By.name("state")));
		dropdown2.selectByVisibleText("Telangana");
		WebElement radio1 = webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
		        //Radio Button1 is selected
		        radio1.click();
		        
		     WebElement radio2 = webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
		        //Radio Button1 is selected
		        radio2.click();
		   
		       
		
		
	}

	@When("^click next button$")
	public void click_next_button() throws Throwable {
		WebElement click = webDriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
        //Radio Button1 is selected
        click.click();

        Alert alert = webDriver.switchTo().alert();
      
     alert.accept();
        
        
	}
	

	@Then("^Navigate to Payment Details page$")
	public void navigate_to_Payment_Details_page() throws Throwable {
		 webDriver.navigate().to("file:///C:/Users/sankekum/Pictures/Conferencebooking/PaymentDetails.html");
		 Thread.sleep(1000);
		 webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
	}
	


	@Given("^Payment Details page$")
	public void payment_Details_page() throws Throwable {
		//webDriver.get("http://localhost:8083/CapgBankingMam/PaymentDetails.html");
		 webDriver.navigate().to("file:///C:/Users/sankekum/Pictures/Conferencebooking/PaymentDetails.html");
		
	}

	@When("^payment details entered$")
	public void payment_details_entered() throws Throwable {
	 
		webDriver.findElement(By.name("txtFN")).sendKeys("Hari");
		webDriver.findElement(By.name("debit")).sendKeys("141020503603");
		webDriver.findElement(By.name("cvv")).sendKeys("225");
		webDriver.findElement(By.name("month")).sendKeys("05");
		webDriver.findElement(By.name("year")).sendKeys("21");
		 Thread.sleep(1000);
		 webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^Click Register button$")
	public void click_Register_button() throws Throwable {
	    WebElement click = webDriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
    //Radio Button1 is selected
	    click.click();
   
	}
	@Then("^Alert box displays \"(.*?)\"$")
	public void alert_box_displays(String arg1) throws Throwable {
		

		    Alert alert = webDriver.switchTo().alert();
		  
		 alert.accept();
		 Thread.sleep(1000);
		 webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	@After
	public void tearDown() {
	webDriver.quit();
	}
	
}
