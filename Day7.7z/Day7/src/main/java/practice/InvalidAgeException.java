package practice;
//custom
public class InvalidAgeException extends Exception{

	public InvalidAgeException()
	{
		
	}
	public InvalidAgeException(String msg)
	{
		super(msg);
	}
	
	@Override
	public String getMessage()
	{
		return "sorrry enter again";
	}
	
}
