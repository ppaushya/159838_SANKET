package practice;
//custom

public class TestMain {

	public static void main(String[] args) throws InvalidAgeException{

		int age=12;
//		try {
		if(age<18)
		{
			throw new InvalidAgeException("Your age should by greater than 18");
		}
//		}catch(InvalidAgeException e) {
//			System.out.println(e.getMessage());
//		}
	}

}
