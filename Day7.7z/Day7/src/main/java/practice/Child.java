package practice;

import java.io.IOException;

class Child extends Parent 
{  
	@Override
	  void msg() throws ArithmeticException 
	  {  
	    System.out.println("TestExceptionChild");  
	  }  
	  public static void main(String args[])
	  {  
	   Parent p=new Child();  
	   p.msg();  
	  }  
	}  

/*1) Rule: If the superclass method does not declare an exception, subclass overridden method cannot 
declare the checked exception.
2) Rule: If the superclass method does not declare an exception, subclass overridden method cannot 
declare the checked exception but can declare unchecked exception.*/

/*If the superclass method declares an exception
1) Rule: If the superclass method declares an exception, subclass overridden method can declare same,
subclass exception or no exception but cannot declare parent exception*/


//https://www.javatpoint.com/exception-handling-with-method-overriding
