package org.banking.model;

public enum AccountType {
	SAVING,CURRENT,FD,RD;
}
