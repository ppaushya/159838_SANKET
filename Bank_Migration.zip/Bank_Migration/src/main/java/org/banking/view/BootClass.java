package org.banking.view;

import java.util.List;
import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;
import org.xyz.service.AccountServiceImpl;
import org.xyz.service.CustomerServiceImpl;
import org.xyz.service.IAccountService;
import org.xyz.service.ICustomerService;
import org.xyz.service.ITransactionService;
import org.xyz.service.TransactionServiceImpl;

public class BootClass {

	static ICustomerService customerService = new CustomerServiceImpl();
	static ITransactionService transactionService = new TransactionServiceImpl();
	
	public static void main(String[] args) {


		do {
			int choice=0;
			while(choice<1 || choice>4) {
				
				System.out.println("1.Create Customer");
				System.out.println("2.List Customers");
				System.out.println("3.Choose Customer");
				System.out.println("4.Exit");
				System.out.println("Enter choice(1/2/3/4) ");
				choice = scanner.nextInt();
				if(choice<1 || choice>4) {
					System.out.println("Invalid entry....try again");
				}
			switch (choice) {
				case 1:
					Customer customer = UserInteraction.promptCustomer();
					boolean success = customerService.createCustomer(customer);
					if(success) {
						UserInteraction.printMessage("Customer created successfully");
					}else {
						UserInteraction.printMessage("Invalid customer details");
					}
					break;
				case 2:
					List<Customer> customers = customerService.getAllCustomers();
					UserInteraction.printCustomers(customers);
					break;
				case 3:
					Customer currentCustomer = UserInteraction.getCustomerFromPromptedCustomerId();
					handleCustomerTasks(currentCustomer);
					break;
				case 4:
					UserInteraction.printMessage("Thank you for banking!");
					System.exit(0);
					break;
				default:
					break;
			}
			System.out.println("Do you wish to continue? [y/n]:");
			String choice = scanner.next();
		}while(choice.charAt(0)=='y' || choice.charAt(0)=='Y');

		UserInteraction.printMessage("Thank you!");
		System.exit(0);
	}
	
	private static void handleCustomerTasks(Customer currentCustomer) {
		IAccountService accountService = new AccountServiceImpl(currentCustomer);
		
		do {
			int totalAccounts = currentCustomer.getAccounts().size();
			int choice=0;
			while(choice<1 || choice>5) {
				System.out.println();
				System.out.println();
				System.out.println("1. Create a new Account");
				System.out.println("2. Perform Transaction");
				System.out.println("3. Transaction summary");
				System.out.println("4. Current Balance");
				System.out.println("5. Cancel");
				System.out.println("Enter your choice[1,2,3,4,5]: ");
				choice = scanner.nextInt();
				if(choice<1 || choice>5) {
					System.out.println("Sorry! Invalid choice. Please try again!");
				}
			}
			switch (choice) {
				case 1:
					Account account = UserInteraction.promptAccount();
					boolean success = accountService.createAccount(account);
					if(success) {
						UserInteraction.printMessage("Account added successfully.");
					}else {
						UserInteraction.printMessage("Invalid account.");
					}
					break;
				case 2:
					if(totalAccounts>0) {
						handleTransactionTasks(currentCustomer,accountService);
					}else {
						UserInteraction.printMessage("No account present.");
					}
					break;
				case 3:
					if(totalAccounts>0) {
						UserInteraction.printTransactionsOfCustomer(transactionService.getAllTransactionsOfCustomer(currentCustomer));
					}else {
						UserInteraction.printMessage("No account present.");
					}
					break;
				case 4:
					if(totalAccounts>0) {
						UserInteraction.printAccountsOfCustomer(currentCustomer);
						Account acc = UserInteraction.getAccountFromPromptedAccountId(accountService);
						UserInteraction.printCurrentBalance(accountService.getCurrentBalanceOfAccount(acc));
					}else {
						UserInteraction.printMessage("No account present.");
					}break;
				case 5:
					return;
				default:
					break;
			}
			System.out.println("Do you wish to continue? [y/n]:");
			String choice = scanner.next();
		}while(choice.charAt(0)=='y' || choice.charAt(0)=='Y');
	}

	private static void handleTransactionTasks(Customer currentCustomer,IAccountService accountService) {
		UserInteraction.printAccountsOfCustomer(currentCustomer);
		Account account = UserInteraction.getAccountFromPromptedAccountId(accountService);
		double balance = accountService.getCurrentBalanceOfAccount(account);
				
		int choice=0;
		while(choice<1 || choice>3) {
			System.out.println();
			System.out.println();
			System.out.println("1. Debit");
			System.out.println("2. Credit");
			System.out.println("3. Fund Transfer");
			System.out.println("4. Cancel");
			System.out.println("Enter your choice[1,2,3,4]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>3) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		switch (choice) {
			case 1:
				Transaction transactionDebit = UserInteraction.promptTransaction(account,balance, 1);
				if(transactionDebit!=null) {
					transactionService.createTransaction(transactionDebit);
				}else {
					UserInteraction.printMessage("Insufficient balance");
				}
				break;
			case 2:
				Transaction transactionCredit = UserInteraction.promptTransaction(account,balance, 2);
				transactionService.createTransaction(transactionCredit);
				break;
			case 3:
				Transaction transactionFundTransfer = UserInteraction.promptFundTransferTransaction(currentCustomer,account,balance,accountService);
				transactionService.createTransaction(transactionFundTransfer);
				return;
			case 4:
				return;
			default:
				break;
		}
		private static LocalDate getDateFromUser(String message) {
			String date="";
			while(!Validator.validateDate(date)) {
				System.out.println(message);
				date = scanner.next();
			}
			String datesplit[] = date.split("-");
			return LocalDate.of(Integer.parseInt(datesplit[2]), Integer.parseInt(datesplit[1]), Integer.parseInt(datesplit[0]));
		}
		
	}
}
